const generalSettings: any = {
  openLink: 'https://1.envato.market/Vm7VRE',
  gitHubLink: 'https://keenthemes.com/metronic'
};

export { generalSettings };
