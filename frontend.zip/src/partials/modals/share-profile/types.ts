export interface IModalShareProfileDocsItem {
  avatar: string;
  userName: string;
  email: string;
  role: string;
}
